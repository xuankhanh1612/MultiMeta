export const environment = {
  production: true,
  META_API_URL: "https://api.multimeta.one/api",
  BDSG_API_URL: "https://api.bdsggroup.com/api",
};
