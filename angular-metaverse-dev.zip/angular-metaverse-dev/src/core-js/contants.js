export const ID_CANVAS_VIEW_3D = 'id-view-3d';

export const LANDING_PAGE_SIGUP = 'https://dev.multimeta.one/signup';
