export interface MetaSetting {
    id: number
    my_terrain: any;
    my_avatar: any;
    metaverse: number;
}
