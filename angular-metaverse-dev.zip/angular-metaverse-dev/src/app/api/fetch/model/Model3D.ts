export interface Model3D{
    id: number;
    name: string;
    file_domain: string;
    file_3d_link: string;
    images_link: string[];
    category: number
}
