export enum MEDIA_TYPES {
    NONE,
    THUMBNAIL,
    AUDIO,
    VIDEO,
    EBOOK,
    STREAM,
}
