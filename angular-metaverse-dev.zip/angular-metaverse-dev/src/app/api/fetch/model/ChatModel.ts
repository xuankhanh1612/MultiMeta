export interface ChatModel {
    user: string;
    content: string;
    avatar: string;
}
