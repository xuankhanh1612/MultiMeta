export interface MediaConfig {
    id: number;
    audio: any;
    video: any;
    ebook: any;
    metaverse: number;
}
